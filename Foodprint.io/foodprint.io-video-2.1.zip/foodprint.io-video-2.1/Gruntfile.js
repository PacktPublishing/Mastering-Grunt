module.exports = function(grunt) {

    grunt.initConfig({

    });
};

