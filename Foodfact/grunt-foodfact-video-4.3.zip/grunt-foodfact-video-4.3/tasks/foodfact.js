module.exports = function (grunt) {

  grunt.registerMultiTask(
    'foodfact',
    'Load the foodfact database',
    function(){

    });
};
